import pandas as pd
import numpy as np

# Load dataset (raw Netflix data)
df = pd.read_csv("netflix_raw.csv")

# --- Step 1: Standardize column names ---
df.columns = df.columns.str.strip().str.lower().str.replace(" ", "_")

# --- Step 2: Handle missing values ---
df['director'] = df['director'].fillna("Unknown")
df['cast'] = df['cast'].fillna("Not Available")
df['country'] = df['country'].fillna("Unknown")
df['date_added'] = pd.to_datetime(df['date_added'], errors="coerce")

# --- Step 3: Remove duplicates ---
df = df.drop_duplicates()

# --- Step 4: Standardize categorical values ---
df['type'] = df['type'].str.strip().str.capitalize()
df['type'] = df['type'].fillna("Unknown")

# --- Step 5: Convert data types ---
df['release_year'] = df['release_year'].astype(int)

# --- Step 6: Save cleaned dataset ---
df.to_csv("netflix_cleaned.csv", index=False)

print("✅ Data cleaning completed. Cleaned file saved as netflix_cleaned.csv")
